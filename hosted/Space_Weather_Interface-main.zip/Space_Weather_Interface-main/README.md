# Space_Weather_Interface

Please run, "SETUP.bat" before using this program.
It will install pip and OpenCV which are neccesary for creating video from downloaded images.

This program is intended for ametuer astronomers and space weather enthusiasts. It pulls from 3 different NASA satelite data sources, 
the Solar and Heliospheric Observatory (SOHO), the Advanced Composition Explorer (ACE) and the Solar Dynamics Observatory (SDO).
