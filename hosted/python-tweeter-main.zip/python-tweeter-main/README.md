# StaringAtTheSun
# For Posting Twitter Posts About The Sun

# THIS PROGRAM REQUIRES DOCKER AND A TWITTER DEVELOPER ACCOUNT
# BEFORE YOU BUILD THE DOCKER FILE : Enter your tokens and secrets into /python/tweeter.py

# Signed: 
# Stefan J Randow, Developer


